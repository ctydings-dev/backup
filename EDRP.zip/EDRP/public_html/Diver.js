var createPrinter = function () {
    var printer = {
        output: "",
        display: function () {
            alert(this.output);
            this.output = '';
        },
        print: function (toPrint) {
            this.output += toPrint;
        },
        println: function (toPrint) {
            this.output = this.output + toPrint + '\n';
        }


    };
    return printer;
};
var createTextAreaPrinter = function (area) {


    var ret = createPrinter();
    ret.area = area;
    ret.getArea = function () {
        return  document.getElementById(this.area);
    };
    ret.display = function () {
        this.getArea().value = this.output;
    };



    return ret;
}


var createDiver = function (unitType, printer) {
    var isImp = unitType.trim().toUpperCase() === 'I';
    var diver = {
        imp: isImp,
        printer: printer,
        isImp: function () {
            return this.imp === true;
        },
        pg: null,
        runningTime: 0,
        getPressureGroup: function () {
            return this.pg;
        },
        tradMode: false,
        isTradMode: function () {
            return this.tradMode === true;
        },
        formatDepth: function (depth) {

            var depth = nearestDepth(depth);
            if (this.isTradMode() === true) {

                while (depth % 10 !== 0) {
                    depth += 1;
                }


            }

            return parseInt('' + depth);
        },
        setPressureGroup: function (toSet) {

            if (toSet + '' === '-1')
            {
                this.println("Congrats! You broke PADI's shitty little device! You probably put in an incorrect SI time, or you exceeded NDL.");
                this.freeze();
            }
            this.pg = toSet;
        },
        addTime: function (time) {

            this.runningTime += time;
        },
        getTime: function () {
            return this.runningTime;
        },
        printRunningTime: function () {
            this.println('Current Running Time: ' + this.getTime() + '(min)');
        },
        isFirst: function () {
            return this.getPressureGroup() === null;
        },
        setup: function (depth) {
            unit = 'm';
            if (this.isImp() === true) {
                unit = 'ft';
            }
            return this.formatDepth(depth);
        },
        maxDepth: function (divetime) {


            this.println('Max Depth for ' + divetime + ' minutes : ' + calcMaxDepthRep(divetime, this.getPressureGroup()) + this.getUnit());
        },
        print: function (toPrint) {
            this.printer.print(toPrint);
        },
        println: function (toPrint) {
            if (this.isFrozen() === true) {
                return;
            }

            this.printer.println(toPrint);
        },
        printPressureGroup: function () {
            this.println("New Pressure Group: " + this.getPressureGroup());

            if (this.ssr === true) {
                this.println("Safety Stop Required!");
            }


        },
        ndl: function (depth) {
            var orig = depth;
            depth = this.setup(depth);
            this.println('NDL for ' + orig + '\\' + depth + ': ' + NDL(depth) + '\n');
        },
        getABT: function (depth) {
            if (this.passesMUD(depth) !== true) {
                this.println("This depth is too deep for a multi level dive, even though a computer can totally do it.");
                //  return;
            }

            this.println('ABT: ' + ANDL(this.getPressureGroup(), depth));
        },
        surface: function () {
            this.lastDepth = 0;
        },
        frozen: false,
        isFrozen: function () {
            return this.frozen === true;
        },
        freeze: function () {
            this.frozen = true;
        },

        getUnit: function () {

            if (this.isImp()) {
                return "'";
            }

            return 'm';
        },

        ndl: function (depth) {
            var origD = depth;
            depth = this.setup(depth);
            this.println('NDL(No PG Accoutned For!) for ' + origD + '->' + depth + ': ' + NDL(depth) + '(min)');

        },

        dive: function (depth, time) {

            if (this.isFrozen()) {
                return;
            }
            this.ssr = false;
            var origD = depth;

            if (this.lastDepthCheck < depth) {

                this.println("WARNING! A DEEPER DIVE IS FOLLOWING A SHALLOW DIVE! ENSURE ORDER IS CORRECT!");

            }

            this.lastDepthCheck = depth;


            depth = this.setup(depth);


            this.println("Dive to " + origD + '->' + depth + this.getUnit() + " for " + time + "(min)");





            if (this.isFirst() === true) {
                var updated = firstPG(depth, time);
                this.setPressureGroup(updated);

                if (extras['stop'] === true) {
                    this.ssr = true;
                    this.addTime(3);
                }

                this.addTime(time);
                this.printPressureGroup();
                this.lastDepth = depth;

                return;
            }
            if (this.lastDepth > 0) {
                var limitCheck = mlLimit(this.getPressureGroup(), depth);
                if (limitCheck < time) {
                    this.println("This time is outside the max ML Limit(" + limitCheck + " min) - 8 MIN SAFETY STOP AND NO DIVE FOR 6 HOURS - NO FLY FOR 18!");

                    this.freeze();
                    return;
                }
            }


            var updated = pgAfterRepDive(this.getPressureGroup(), depth, time);
            this.setPressureGroup(updated);
            if (extras['stop'] === true) {
                this.addTime(3);
                this.ssr = true;

            }
            this.addTime(time);
            this.printPressureGroup();
            this.lastDepth = depth;
        },
        minSurfaceInterval: function (targetPG) {

            this.println(minSI(this.getPressureGroup(), targetPG));
        },
        printMinSurfaceIntervalForDive: function (depth, time) {
            var ogd = depth;
            var waitTime = this.minSurfaceIntervalForDive(depth, time);
            this.println("Min SI for dive(" + ogd + this.getUnit() + '-' + time + '): ' + this.displayTime(waitTime));
        },
        minSurfaceIntervalForDive: function (depth, time) {
            var ogd = depth;
            depth = this.setup(depth);
            var pg2 = minRepPG(depth, time);
            var waitTime = minSI(this.getPressureGroup(), pg2);
            if (this.req1Hour() === true && waitTime < 60) {
                waitTime = 60;
            }
            if (this.req3Hour() === true && waitTime < 180) {
                waitTime = 180;
            }
            return waitTime;
        },
        displayTime: function (time) {
            var hours = 0;
            while (time > 60) {
                hours++;
                time -= 60;
            }
            if (time < 10) {
                time = '0' + time;
            }

            var ret = hours + ':' + time;
            return ret;
        },
        minSurfaceIntervalBetweenTwoDives(depth1, time1, depth2, time2) {
            var ogd1 = depth1;
            var ogd2 = depth2;
            depth1 = this.setup(depth1);
            depth2 = this.setup(depth2);
            var pg1 = firstPG(depth1, time1);
            var pg2 = minRepPG(depth2, time2);
            var time = minSI(pg1, pg2);
            this.println("Min SI for two dives(" + ogd1 + this.getUnit() + '-' + time1 + ') (' + ogd2 + this.getUnit() + '-' + time2 + '): ' + time);
        },
        req1Hour: function () {
            if (this.getPressureGroup() === 'W')
                return true;
            if (this.getPressureGroup() === 'X')
                return true;
            if (this.getPressureGroup() === 'Y')
                return true;
            if (this.getPressureGroup() === 'Z')
                return true;
            return false;
        },
        req3Hour: function () {

            if (this.getPressureGroup() === 'Y')
                return true;
            if (this.getPressureGroup() === 'Z')
                return true;
            return false;
        },
        diveASAP: function (depth, time) {

            var si = this.minSurfaceIntervalForDive(depth, time);
            this.surfaceInterval(si);
            this.dive(depth, time);
        },

        passesMUD: function (depth) {

            if (this.lastDepth === 0) {
                return true;
            }



            if (this.isImp()) {
                if (this.lastDepth < 60)
                {
                    return depth <= 40;
                }
                if (this.lastDepth < 80)
                {
                    return depth <= 50;
                }

                if (this.lastDepth < 95)
                {
                    return depth <= 70;
                }
                return depth <= 70;
            }

            if (this.lastDepth <= 20)
            {
                return depth <= 12;
            }


            if (this.lastDepth <= 22)
            {
                return depth <= 16;
            }


            if (this.lastDepth <= 28)
            {
                return depth <= 20;
            }
            if (this.lastDepth <= 34)
            {
                return depth <= 24;
            }


            return depth <= 26;





        },

        surfaceInterval: function (time) {
            this.lastDepth = 0;
            if (this.req1Hour() && time < 60) {
                this.println('MIN SI(1) RULE VIOLATED!');
                this.freeze();
                return;
            }
            if (this.req1Hour() && time < 180) {
                this.println('MIN SI(3) RULE VIOLATED!');
                this.freeze();
                return;
            }

            this.addTime(time);
            this.println("Surface interval of : " + time + "(min)");
            var updated = calcPGafterSI(this.getPressureGroup(), time);

            this.setPressureGroup(updated);
            this.println("New Pressure Group: " + this.getPressureGroup());
        }
    };
    return diver;
}
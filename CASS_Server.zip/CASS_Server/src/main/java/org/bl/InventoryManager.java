package org.bl;

import org.server.db.Inventory;

public class InventoryManager {

    private Inventory inv;





}

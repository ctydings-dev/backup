package org.server.db;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;


public abstract class DBObject<T> {

    private static String currentUser = "DEFAULT";



    private static SessionFactory sessionFactory;

    public static void setSessionFactory(SessionFactory toSet) {
        sessionFactory = toSet;
    }


    public static Session getSession(){
        return sessionFactory.openSession();
    }

    public abstract String getTableName();





    public void save(User user){
        Session ses = getSession();

        Transaction trans = ses.beginTransaction();

        ses.persist(this);
        ses.flush();
        trans.commit();

        if(this.requriesLog()){
            addSaveLog( user);
        }


    }


    public void update(){

        Session ses = getSession();


        Transaction tx = ses.beginTransaction();
        DBObject updated  = ses.merge(this);
        tx.commit();


    }



    protected boolean requriesLog(){
        return true;
    }



    public void clearAll(){

        Session ses = getSession();

        Transaction trans = ses.beginTransaction();


        org.hibernate.query.Query query =         ses.createQuery("DELETE FROM " + this.getTableName());

        // query.executeUpdate();
        ///  trans.commit();
    }

    public void save(){

        save(new User(currentUser));
    }

    public void addSaveLog(User user){

        Log toAdd = createLog(this.getTableName(), user);
        toAdd.save();


    }

    protected Log createLog(String tableName, User user) {
        return  new Log(tableName, user, LogType.CREATE, "ROW CREATED");


    }


    public NativeQuery<T> createQuery(String sql){

        return this.getSession().createNativeQuery(sql);


    }




}

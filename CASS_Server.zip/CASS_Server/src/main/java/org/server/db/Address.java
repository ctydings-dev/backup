package org.server.db;

import jakarta.persistence.*;

@Entity
@Table(name = "address")
public class Address extends ActiveBase{



    @Column(name = "street")
    private String street;

    @Column(name = "street_2")
    private String street2;

    @Column(name = "city")
    private String city;


    private String zip;
    @ManyToOne
    @JoinColumn(name = "state")
    private State state;


    public Address(String street,String city, String zip, State state) {
       super();
        this.street = street;
        this.zip = zip;
        this.state = state;
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getStreet2() {
        return street2;
    }

    public void setStreet2(String street2) {
        this.street2 = street2;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }


    @Override
    public String getTableName() {
        return "ADDRESS";
    }
}

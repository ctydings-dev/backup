package org.server.db;

public enum InventoryActionType {

   ADDITION(true), DELETION(false),SALE(true),SHIPMENT(true), CORRECTION(false) ;


   private boolean isAddition;

    InventoryActionType(boolean isAddition){
      this.isAddition = isAddition;
   }

   public int convertQty(int qty){
       if( this.isAddition  == true){
          return qty;
       }

       return qty* -1;
   }


}

package org.server.db;

import jakarta.persistence.*;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

@Entity
@Table(name = "inventory_qty")
public class InventoryQty extends DBObject {


    @Id
    @GeneratedValue(strategy =GenerationType.SEQUENCE)

    private Integer id;



    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inventory")
    private Inventory inventory;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sku")
    private SKU sku;


    @Column(name = "qty")
    private Integer qty;


    public InventoryQty(Integer id, Inventory inventory, SKU sku, Integer qty) {
        this.id = id;
        this.inventory = inventory;
        this.sku = sku;
        this.qty = qty;
    }


    public InventoryQty() {
    }

    public InventoryQty(Inventory inventory, SKU skuPrice, Integer qty) {
        this.inventory = inventory;
        this.sku = skuPrice;

        this.qty = qty;
    }

    protected boolean requriesLog(){
        return false;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public SKU getSku() {
        return sku;
    }

    public void setSku(SKU sku) {
        this.sku = sku;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public String getTableName() {
        return "INVENTORY_QTY";
    }


    public static void updateInventory(InventoryAction action){

        int qty = action.getQty();
        qty = action.getType().convertQty(qty);

        if( hasEntry(action.getInventory(), action.getSku()) == false){

            InventoryQty invQty = new InventoryQty(action.getInventory(),action.getSku(),qty);
           invQty.save();
            return;
        }
        InventoryQty toUpdate = getEntry(action.getInventory(), action.getSku());
        Session ses = getSession();



        toUpdate.setQty(toUpdate.getQty() + qty);

toUpdate.update();

    }


    public static InventoryQty getEntry(Inventory host, SKU sku){

        String hql = "SELECT qty FROM InventoryQty qty WHERE qty.inventory = :inv AND qty.sku = :sku";

       return getSession()
                .createQuery(hql, InventoryQty.class)
                .setParameter("inv", host)
                .setParameter("sku", sku)
                .uniqueResult();


    }




    public static boolean hasEntry(Inventory host, SKU sku) {
        String hql = "SELECT COUNT(qty) FROM InventoryQty qty WHERE qty.inventory = :inv AND qty.sku = :sku";

        Long count = getSession()
                .createQuery(hql, Long.class)
                .setParameter("inv", host)
                .setParameter("sku", sku)
                .uniqueResult();

        return count != null && count > 0;
    }



}
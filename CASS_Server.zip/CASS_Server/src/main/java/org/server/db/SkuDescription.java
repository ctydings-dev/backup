package org.server.db;

import jakarta.persistence.*;
import org.hibernate.query.NativeQuery;

import java.util.List;

@Entity
@Table(name = "sku_description")
public class SkuDescription extends Base {


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sku")
    private SKU sku;

    @Column(name = "value")
private String value;

    @Enumerated(EnumType.STRING)
    @Column(name = "type" , length = 16)
private SkuDescriptionType type;

    public SkuDescription(SKU sku, SkuDescriptionType type, String value) {
        this.sku = sku;
        this.value = value;
        this.type = type;
    }

    public String getTableName() {
        return "SKU_DESCRIPTION";
    }





}
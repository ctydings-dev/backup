package org.server.db;

import jakarta.persistence.*;

@Entity
@Table(name = "inventory")
public class Inventory extends Base {


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer")
    private Customer customer;


    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    public Inventory() {
    }

    public Inventory(Customer customer, String name, String description) {
        this.customer = customer;
        this.name = name;
        this.description = description;
    }

    public String getTableName() {
        return "INVENTORY";
    }





}
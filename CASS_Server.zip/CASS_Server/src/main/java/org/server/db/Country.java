package org.server.db;

import jakarta.persistence.*;
import org.hibernate.query.NativeQuery;

import java.util.List;

@Entity
@Table(name = "country")
public class Country extends Base {



    @Column(name = "name")
    private String name;

    @Column(name = "code", length = 10)
    private String code;

    public Country() {}

    public Country( String name, String code){
        this.name = name;
        this .code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTableName() {
        return "COUNTRY";
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }




    public static List<Country> getAllCountries(){
        String stmt=  "SELECT * FROM country";
        NativeQuery<Country> query = getSession().createNativeQuery(stmt, Country.class);
        return query.getResultList();
    }


    public static Country getCountry(String countryCode){

        String stmt=  "SELECT * FROM country con WHERE con.code = :code";
        NativeQuery<Country> query = getSession().createNativeQuery(stmt, Country.class);
query.setParameter("code", countryCode);

return query.getSingleResult();


    }




}
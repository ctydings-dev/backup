package org.server.db;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "user")
public class User extends ActiveBase{
    @Override
    public String getTableName() {
        return "USER";
    }

private String name;

    public User(String name) {
        this.name = name;
    }


    public String getName() {
        return name;
    }
}

package org.server.db;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.query.NativeQuery;

import java.util.List;

@Entity
@Table(name = "customer")
public class Customer extends  ActiveBase {



    @Column(name = "first_name")
    private String firstName;

    @Column(name = "middle_name")
    private String middleName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "code")
    private String code;

    @Column(name = "description")
    private String descripation;


    public Customer(String code, String firstName, String middleName, String lastName) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.code = code;
    }

    @Override
    public String getTableName() {
        return "CUSTOMER";
    }
}
package org.server.db;

public enum SkuDescriptionType {

   COLOR, SIZE,  MANUFACTURER, SUPPLIER



}

package org.server.db;

import jakarta.persistence.*;

import java.sql.Timestamp;

@Entity
@Table(name = "log")
public class Log extends Base{

    @Column(name = "target_table")
  private String tableName;

    @Enumerated(EnumType.STRING)
    @Column(name = "type")
  private LogType type;

    @Column(name = "message")
  private String message;

    @Column(name = "user")
  private String user;

@Column(name = "time")
  private java.sql.Timestamp sqlTimestamp;


    @Override
    public String getTableName() {
        return getLogName();
    }


    public static String getLogName() {
        return "LOG";
    }

    public Log(String tableName, User user, LogType type, String message) {
       super();
        this.tableName = tableName;
        this.type = type;
        this.message = message;
        this.user = user.getName();
        sqlTimestamp = new Timestamp(System.currentTimeMillis());
    }

    protected boolean requriesLog(){
        return false;
    }

}

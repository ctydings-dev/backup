package org.server.db;

import jakarta.persistence.*;

@Entity
@Table(name = "sku_price")
public class SkuPrice extends ActiveBase {


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sku")
    private SKU sku;

    @Column(name = "price")
private double price;

    public SkuPrice(SKU sku, double price) {
        this.sku = sku;
        this.price = price;
    }

    public SKU getSku() {
        return sku;
    }

    public double getPrice() {
        return price;
    }

    public String getTableName() {
        return "SKU_PRICE";
    }





    public static boolean hasPrice( SKU sku, double price) {
        String hql = "SELECT COUNT(qty) FROM SkuPrice qty WHERE qty.price = :price AND qty.sku = :sku AND qty.active = 1";

        Long count = getSession()
                .createQuery(hql, Long.class)
                .setParameter("price", price)
                .setParameter("sku", sku)
                .uniqueResult();

        return count != null && count > 0;
    }





    protected Log createLog(String tableName, User user) {
        return  new Log(tableName, user, LogType.PRICE, "SKU PRICE ADDED");


    }



}
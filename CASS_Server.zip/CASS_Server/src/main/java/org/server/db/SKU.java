package org.server.db;

import jakarta.persistence.*;

@Entity
@Table(name = "sku")
public class SKU extends ActiveBase{



    @Column(name = "sku")
    private String sku;

    @Column(name = "upc")
    private String upc;

    @Column(name = "description")
    private String description;

    @Column(name = "mfg_code")
    private String mfgCode;

    @Column(name = "countable")
    private Integer countable;

    public SKU(String sku, String upc, String description, boolean countable) {
        this.sku = sku;
        this.upc = upc;
        this.description = description;
        this.countable =0;

        if(countable == true){
            this.countable = 1;
        }
    }

    public SKU(){

    }

    public SKU(String sku, String upc, String description) {
        this.sku = sku;
        this.upc = upc;
        this.description = description;
        this.countable =1;

    }

    protected Log createLog(String tableName, User user) {
        return  new Log(tableName, user, LogType.SKU, "SKU CREATED");


    }


    @Override
    public String getTableName() {
        return "SKU";
    }
}

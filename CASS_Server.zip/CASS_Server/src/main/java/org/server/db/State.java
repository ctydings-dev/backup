package org.server.db;

import jakarta.persistence.*;


@Entity
@Table(name = "state")
public class State extends Base {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "country")
    private Country country;

    @Column(name = "name")
    private String name;

    @Column(name = "code")
    private String code;

    public State() {}

    public State( String name, String code, Country con){
        this.name = name;
        this .code = code;
        this.country = con;
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public String getTableName(){
        return "STATE";
    }

}

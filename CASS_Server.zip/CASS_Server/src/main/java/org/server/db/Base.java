package org.server.db;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import org.hibernate.SessionFactory;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.UUID;

@MappedSuperclass
public abstract class Base<T> extends DBObject {

    private static String currentUser = "DEFAULT";



    @Id
    @GeneratedValue(strategy =GenerationType.UUID)
    @JdbcTypeCode(SqlTypes.CHAR)
    private UUID id;

    private static SessionFactory sessionFactory;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }





}

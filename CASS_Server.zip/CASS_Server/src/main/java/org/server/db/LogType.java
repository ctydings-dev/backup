package org.server.db;

public enum LogType {

    CREATE, UPDATE, ACTIVATE,INACTIVATE, INVENTORY, PRICE, SKU



}

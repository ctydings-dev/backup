package org.server.db;

import jakarta.persistence.*;

@Entity
@Table(name = "inventory_action")
public class InventoryAction extends Base {


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sku_price")
    private SkuPrice sku;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "inventory")
    private Inventory inventory;


    @Column(name = "qty")
private Integer qty;

    @Enumerated(EnumType.STRING)
    @Column(name = "type" , length = 16)
private InventoryActionType type;

    public InventoryAction(Inventory inventory, SkuPrice sku, InventoryActionType type, Integer value) {
        this.sku = sku;
        this.qty = value;
        this.type = type;
        this.inventory = inventory;
    }

    public String getTableName() {
        return "INVENTORY_ACTION";
    }


    protected Log createLog(String tableName, User user) {
        return  new Log(tableName, user, LogType.INVENTORY, "INVENTORY ACTIION");


    }

    public SkuPrice getSkuPrice() {
        return sku;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public Integer getQty() {
        return qty;
    }

    public SKU getSku(){
        return this.getSkuPrice().getSku();
    }

    public InventoryActionType getType() {
        return type;
    }
}
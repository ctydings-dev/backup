package org.server.db;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class ActiveBase extends Base{

    @Column(name = "active")
    private Integer active;

    public ActiveBase(){
        active = 1;
    }

    public ActiveBase(boolean active){
        this.active = 0;

        if(active == true){
            this.active = 1;
        }


    }





}

package org.example;

import org.server.db.*;

public class InvCreator {




    public static void createInventory(Inventory host){
        createSku(host,"The Explorer' Hookah Gas-Powered Setup","F390X",0,0);
        createSku(host,"#18 Line (1 Pound Spool)","30.100.018",0,0);
        createSku(host,"#24 Braided Nylon Line (1 lb)","30.030.024",0,0);
        createSku(host,"#24 Line (1 Pound Spool)","30.100.024",0,0);
        createSku(host,"#36 Line (1 Pound Spool)","30.100.036",0,0);
        createSku(host,"#420 Stainless Steel Dive Knife","K5-C61A-TBU",0,0);
        createSku(host,"(SRB3200)Service Kit","4000-17",5,25);
        createSku(host,".38 Special BP&W System (Black)","T.038.005",1,335);
        createSku(host,".38 Special BP&W System (Green)","T.038.005.GR",1,335);
        createSku(host,".38 Special BP&W System (Grey)","T.038.005.GY",0,0);
        createSku(host,".38 Special BP&W System (Orange)","T.038.005.OR",0,0);
        createSku(host,".38 Special BP&W System (Pink)","T.038.005.PK",0,0);
        createSku(host,".38 Special BP&W System (Yellow)","T.038.005.YL",1,335);
        createSku(host,".38 Special Wing (Black)","T.038.001",6,402);
        createSku(host,".38 Special Wing (Grey)","T.038.001.GR",0,0);
        createSku(host,".38 Special Wing (Orange)","T.038.001.OR",1,67);
        createSku(host,".38 Special Wing (Pink)","T.038.001.PK",1,67);
        createSku(host,"0550 Protector Transport Case","0550-000-110",0,0);
        createSku(host,"1.0m Tech SMB (Orange)","60040-1.0",18,154.8);
        createSku(host,"1.4m Tech SMB (Orange)","60040-1.4",13,169);
        createSku(host,"1.5mm Carbone Amara Glove (Large)","7CNA15-L",0,0);


    }


    public static  void createSku(Inventory host, String sku, String desc, int qty, double price){

SKU toAdd = new SKU(sku,sku,desc);
toAdd.save();
        SkuPrice skuPrice = new SkuPrice(toAdd, price);
skuPrice.save();
        InventoryAction addition = new InventoryAction(host, skuPrice, InventoryActionType.ADDITION, qty);
        addition.save();


        InventoryQty.updateInventory(addition);


    }










}

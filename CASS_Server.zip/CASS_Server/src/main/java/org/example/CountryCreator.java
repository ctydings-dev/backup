package org.example;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.server.db.Country;
import org.server.db.State;

public class CountryCreator {


    public static void createCountries(Session session) {

    // Country toDel = new Country("NA","NA");
    // toDel.clearAll();
        Transaction trans = session.beginTransaction();
        createCountry("UNITED STATES", "US");
        createCountry("CANADA", "CA");
        createCountry("UNITED KINGDOM", "GB");
        createCountry("FRANCE", "FR");
        createCountry("GERMANY", "DE");


        trans.commit();
    }


    private static void createState(String name, String code, Country country) {

        State toAdd = new State(name, code, country);
        toAdd.save();
    }

    public static void addUSStates(Country us) {
      //  State toAdd = new State(null,null,null);
     //  toAdd.clearAll();


        createState("ALABAMA", "AL", us);
        createState("ALASKA", "AK", us);
        createState("ARIZONA", "AZ", us);
        createState("ARKANSAS", "AR", us);
        createState("CALIFORNIA", "CA", us);
        createState("COLORADO", "CO", us);
        createState("CONNETICUIT", "CT", us);
        createState("DELAWARE", "DE", us);
        createState("FLORIDA", "FL", us);
        createState("GEORGIA", "GA", us);
        createState("HAWAII", "HI", us);
        createState("IDAHO", "ID", us);
        createState("ILLINOIS", "IL", us);
        createState("INDIANA", "ID", us);
        createState("IOWA", "IA", us);
        createState("KANSAS", "KA", us);
        createState("KENTUCKY", "KY", us);
        createState("LOUISIANA", "LA", us);
        createState("MAINE", "ME", us);
        createState("MARYLAND", "MD", us);
        createState("MASSACHUSETTS", "MA", us);
        createState("MICHIGAN", "MI", us);
        createState("MINNESOTA", "MN", us);
        createState("MISSISSIPPI", "MS", us);
        createState("MISSOURI", "MO", us);
        createState("MONTANA", "MN", us);
        createState("NEBRASKA", "NE", us);
        createState("NEVADA", "NV", us);
        createState("NEW HAMPSHIRE", "NH", us);
        createState("NEW JERSEY", "NJ", us);
        createState("NEW MEXICO", "NM", us);
        createState("NEW YORK", "NY", us);
        createState("NORTH CAROLINA", "NC", us);
        createState("NORTH DAKOTA", "ND", us);
        createState("OHIO", "OH", us);
        createState("OKLAHOMA", "OK", us);
        createState("OREGON", "OR", us);
        createState("PENNSYLVANIA", "PA", us);
        createState("RHODE ISLAND", "RI", us);
        createState("SOUTH CAROLINA", "SC", us);
        createState("SOUTH DAKOTA", "SD", us);
        createState("TENNESSES", "TN", us);
        createState("TEXAS", "TX", us);
        createState("UTAH", "UT", us);
        createState("VERMONT", "VT", us);
        createState("VIRGINIA", "VA", us);
        createState("WASHINGTON", "WA", us);
        createState("WEST VIRGINIA", "WV", us);
        createState("WISCONSIN", "WI", us);
        createState("WYOMING", "WY", us);
        createState("DISTRICT OF COLUMBIA", "DC", us);
    }

    private static void createCountry(String name, String code) {
        Country toAdd = new Country(name, code);
        toAdd.save();


    }


}

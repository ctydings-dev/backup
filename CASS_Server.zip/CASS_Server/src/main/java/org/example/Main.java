package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.server.db.*;

import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
       setUp();
       System.out.printf("Hello and welcome2!");

    }

    protected static void setUp() {
        // 1. Create a StandardServiceRegistry and explicitly tell it to load the XML config file
        StandardServiceRegistry registry = new StandardServiceRegistryBuilder().build();

        try {
            // 2. Pass the registry to MetadataSources
            Metadata sources = new MetadataSources(registry)
                    .addAnnotatedClass(org.server.db.Country.class).addAnnotatedClass(org.server.db.User.class).addAnnotatedClass(org.server.db.Log.class).addAnnotatedClass(org.server.db.State.class).addAnnotatedClass(org.server.db.Address.class)
                    .addAnnotatedClass(org.server.db.SKU.class)
                    .addAnnotatedClass(org.server.db.SkuDescription.class)
                    .addAnnotatedClass(org.server.db.SkuPrice.class)
                    .addAnnotatedClass(org.server.db.Customer.class)
                    .addAnnotatedClass(org.server.db.Inventory.class)
                    .addAnnotatedClass(org.server.db.InventoryAction.class)
                    .addAnnotatedClass(org.server.db.InventoryQty.class)

                    .buildMetadata();

            SessionFactory sessionFactory = sources.buildSessionFactory();

           Base.setSessionFactory(sessionFactory);


        CountryCreator.createCountries(sessionFactory.openSession());



User def = new User("ROOT");
List<Country> countries = Country.getAllCountries();
System.out.println("SIZE IS " + countries.size());

Country found = Country.getCountry("US");

CountryCreator.addUSStates(found);


      /*      Address adr = new Address("10030 GEBHART DR","ANCHORAGE", "99515", ak );
//adr.save();

System.out.println("NAME IS " + found.getName());
*/


Customer chris = new Customer("SXY_MTHR_FCKR", "CHRISTOPHER","MICHAEL","TYDINGS");
chris.save();
Inventory cInv = new Inventory(chris,"CMT_INV", "TYDINGS INVENTORY");
cInv.save();

InvCreator.createInventory(cInv);




  } catch (Exception e) {
            StandardServiceRegistryBuilder.destroy(registry);
            e.printStackTrace();
        }
    }

      }
plugins {
    id("java")
    application
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation(platform("org.junit:junit-bom:6.0.0"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    implementation("org.hibernate.orm:hibernate-core:7.4.15.Final")
    runtimeOnly("mysql:mysql-connector-java:8.0.33")
    implementation("com.mysql:mysql-connector-j:9.1.0")
    implementation("jakarta.persistence:jakarta.persistence-api:3.1.0")

}

tasks.test {
    useJUnitPlatform()
}
application {
    mainClass.set("org.example.Main") // 2. Specify your fully qualified main class name
}
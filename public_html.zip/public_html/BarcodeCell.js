

const xMargin = 17;
const yMargin = 0;
const textFont = 14;
const textSize = 12;
const width = 2;
const height = 30;
var createBarcodeCell = function (x, y, code, row1, row2) {

    if (row1 === undefined || row1 === null) {
        row1 = "";
    }

    if (row2 === undefined || row2 === null) {
        row2 = "";
    }

    var ret = {
        x: x,
        y: y,
        code: code,
        row1: row1,
        row2: row2,
        codeWidth: 0,
        codeHeight: 0,
        codeTextSize: 15,
        width: 245,
        height: 96,
        getCellWidth: function () {
            return this.width;
        },
        getCellHeight: function () {
            return this.height;
        },

        textSize: textSize,
        selected: false,
        row1Format: null,
        rwo2Format: null,
        setRow1Format(toSet) {
            this.row1Format = toSet;
        },
        setRow2Format(toSet) {
            this.row2Format = toSet;
        },
        getRow1Format() {
            return this.row1Format;
        },
        getRow2Format() {
            return this.row2Format;

        },
        getCodeWidth() {
            return this.codeWidth;
        },
        getCodeHeight() {
            return this.codeHeight;
        },
        setCodeWidth(value) {
            this.codeWidth = value;
        },
        setCodeHeight(value) {
            this.codeHeight = value;
        },
        getCodeTextSize: function () {
            return this.codeTextSize;
        },
        setCodeTextSize: function (value) {
            this.codeTextSize = value;
        },

        isSelected: function () {
            return this.selected;
        },
        select: function () {
            this.selected = !this.selected;
        },
        unselect: function () {
            this.selected = false;
        },

        getFontSize: function () {
            return this.textSize;
        },
        getFont: function () {
            return this.getFontSize() + "px " + this.getFontFamily();
        },
        fontFamily: 'monospace',
        getFontFamily: function () {

            return this.fontFamily;
        },
        setFontFamily: function (toSet) {
            this.fontFamily = toSet;
        },
        setTextSize: function (size) {
            this.textSize = size;
        },
        getX: function () {
            return this.x;
        },
        getY: function () {
            return this.y;
        },
        getXCoor: function () {
            return this.getX() * (xMargin + this.getCellWidth());
        },
        getYCoor: function () {
            return this.getY() * (this.getCellHeight() + yMargin);
        },
        getCode: function () {
            return this.code;
        },
        setCode: function (toSet) {
            if (toSet.length >= 7) {
                this.setCodeWidth(1);
            }

            this.code = toSet;
        },
        getRow1: function () {
            return this.row1;
        },
        getRow2: function () {
            return this.row2;
            ;
        },
        setRow1: function (toSet) {
            this.row1 = toSet;
        },
        setRow2: function (toSet) {
            this.row2 = toSet;
        },

        paddings: {
            x: {barcode: 0,
                row1: 0,
                row2: 0},
            y: {barcode: 0,
                row1: 75,
                row2: 0}
        },
        getWarningLength: function () {
            return 36;
        },
        getCodeWarningLength: function () {
            return 18;
        },
        getPaddings: function () {
            return this.paddings;
        },
        setPaddings: function (toSet) {
            this.paddings = toSet;
        },
        getSelectColor: function () {
            return '#03fcb1';
        },
        getWarningColor: function () {
            return 'rgba(219, 154, 166)';
        },
        getWarningSelectedColor: function () {
            return '#c4e84f';
        },

        printCell: function (dest, drawer, format, printBorders) {
            var color = 'rgba(0, 0, 0, 0)';
            var problematic = false;
            dest.font = this.getFont();



            var width = dest.measureText(this.getRow1()).width;
            var width2 = dest.measureText(this.getRow2()).width;
            if (width < width2) {
                width = width2;
            }
            if (printBorders === true) {

                if (width > this.getCellWidth()) {

                    problematic = true;
                }
                if (this.getCode().length > this.getCodeWarningLength()) {
                    problematic = true;
                }


            }

            if (problematic === true) {
                color = this.getWarningColor();
                dest.fillStyle = color;
                dest.fillRect(this.getXCoor(), this.getYCoor() + Y_START, this.getCellWidth(), this.getCellHeight());
                dest.stroke();
            }




            if (this.isSelected() === true) {
                color = this.getSelectColor();
                if (problematic === true) {
                    color = this.getWarningSelectedColor();
                }
                dest.fillStyle = color;
                dest.fillRect(this.getXCoor(), this.getYCoor() + Y_START, this.getCellWidth(), this.getCellHeight());
                dest.stroke();
            }


            JsBarcode("#" + drawer, this.getCode(), {
                format: format,
                flat: false,
                width: this.getCodeWidth(),
                height: this.getCodeHeight(),
                displayValue: true,
                fontSize: this.getCodeTextSize(),
                background: color
            });

            var source = document.getElementById(drawer);

            // alert(source.getContext('2d').imageSmoothingEnabled);
            source.getContext('2d').imageSmoothingEnabled = false;



            var textX = this.getXCoor() + this.getCellWidth() / 2 + this.getPaddings().x.row1;

            var xCoor = this.getXCoor() + this.getCellWidth() / 2 - source.width / 2;




            dest.fillStyle = "rgba( 0,0, 0, 1)";
            dest.imageSmoothingEnabled = false;


            if (this.getCode().trim().length > 1) {
                if (source !== null && source !== undefined) {
                    dest.drawImage(source, xCoor, this.getYCoor() + Y_START);
                }
            }
            dest.textAlign = "center";




            dest.fillText(this.getRow1(), textX, this.getYCoor() + this.getPaddings().y.row1 + Y_START);
            textX = this.getXCoor() + this.getCellWidth() / 2 + this.getPaddings().x.row2;
            dest.fillText(this.getRow2(), textX, this.getYCoor() + this.getPaddings().y.row1 + this.getTextHeight() + Y_START);
            if (printBorders === true) {
                dest.rect(this.getXCoor(), this.getYCoor() + Y_START, this.getCellWidth(), this.getCellHeight());
                dest.stroke();
            }
        },
        getTextHeight: function () {
            return 15;
        },
        isInCell: function (x, y) {

            y -= 70;

            if (x < this.getXCoor()) {
                return false;
            }
            if (x > this.getXCoor() + this.getCellWidth()) {
                return false;
            }




            if (y <= this.getYCoor()) {
                return false;
            }
            if (y >= this.getYCoor() + this.getCellHeight() + Y_START) {
                return false;
            }
            return true;
        }
    };

    ret.setCodeHeight(height);
    ret.setCodeWidth(width);

    return ret;
};



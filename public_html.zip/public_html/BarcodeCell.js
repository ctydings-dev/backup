var MARES_CODE = true;



const xWidth = 245;
const yWidth = 96;
const xMargin = 17;
const yMargin = 0;
const textFont = 14;
const textSize = 12;
const width = 2;
const height = 30;
var createBarcodeCell = function (x, y, code, row1, row2) {

    if (row1 === undefined || row1 === null) {
        row1 = "";
    }

    if (row2 === undefined || row2 === null) {
        row2 = "";
    }

    var ret = {
        x: x,
        y: y,
        code: code,
        row1: row1,
        row2: row2,
        codeWidth: 0,
        codeHeight: 0,
        codeTextSize: 20,

        textSize: textSize,
        selected: false,
        row1Format: null,
        rwo2Format: null,
        setRow1Format(toSet) {
            this.row1Format = toSet;
        },
        setRow2Format(toSet) {
            this.row2Format = toSet;
        },
        getRow1Format() {
            return this.row1Format;
        },
        getRow2Format() {
            return this.row2Format;

        },
        getCodeWidth() {
            return this.codeWidth;
        },
        getCodeHeight() {
            return this.codeHeight;
        },
        setCodeWidth(value) {
            this.codeWidth = value;
        },
        setCodeHeight(value) {
            this.codeHeight = value;
        },
        getCodeTextSize: function () {
            return this.codeTextSize;
        },
        setCodeTextSize: function (value) {
            this.codeTextSize = value;
        },

        isSelected: function () {
            return this.selected;
        },
        select: function () {
            this.selected = true;
        },
        unselect: function () {
            this.selected = false;
        },

        getTextSize: function () {
            return this.textSize;
        },
        setTextSize: function (size) {
            this.textSize = size;
        },
        getX: function () {
            return this.x;
        },
        getY: function () {
            return this.y;
        },
        getXCoor: function () {
            return this.getX() * (xMargin + xWidth);
        },
        getYCoor: function () {
            return this.getY() * (yWidth + yMargin);
        },
        getCode: function () {
            return this.code;
        },
        setCode: function (toSet) {
            this.code = toSet;
        },
        getRow1: function () {
            return this.row1;
        },
        getRow2: function () {
            return this.row2;
            ;
        },
        setRow1: function (toSet) {
            this.row1 = toSet;
        },
        setRow2: function (toSet) {
            this.row2 = toSet;
        },

        paddings: {
            x: {barcode: 0,
                row1: 0,
                row2: 0},
            y: {barcode: 0,
                row1: 75,
                row2: 0}
        },
        getPaddings: function () {
            return this.paddings;
        },
        setPaddings: function (toSet) {
            this.paddings = toSet;
        },
        printCell: function (dest, drawer, format, printBorders) {
            if (format === null || format === undefined) {
                JsBarcode("#" + drawer, this.getCode(), {
                    flat: false
                });
            } else
            {
                JsBarcode("#" + drawer, this.getCode(), {
                    format: format,
                    flat: false,
                    width: this.getCodeWidth(),
                    height: this.getCodeHeight(),
                    displayValue: true,
                    fontSize: this.getCodeTextSize()
                });
            }
            var source = document.getElementById(drawer);
            dest.font = this.getTextSize() + "px monospace";
            var text = this.getBarcodeWidth() + "";
            var textX = this.getBarcodeWidth() / 2;
            textX = xWidth / 2 - this.getRow1Width();
            textX += this.getXCoor() + this.getPaddings().x.row1;
            var xCoor = this.getXCoor() + xWidth / 2 - this.getBarcodeWidth() / 2 + (this.getPaddings().x.barcode * 1.0);

            if (this.isSelected() == true) {

                dest.fillStyle = "rgba( 255,0, 0, 0.5)";
                dest.fillRect(this.getXCoor(), this.getYCoor() + Y_START, xWidth, yWidth);
                dest.stroke();
            }

            dest.fillStyle = "rgba( 0,0, 0, 1)";


            if (this.getCode().trim().length > 1) {
                dest.drawImage(source, xCoor, this.getYCoor() + Y_START);
            }
            dest.fillText(this.getRow1(), textX, this.getYCoor() + this.getPaddings().y.row1 + Y_START);
            textX = xWidth / 2 - this.getRow2Width();
            textX += this.getXCoor() + (1.0 * this.getPaddings().x.row2);
            dest.fillText(this.getRow2(), textX, this.getYCoor() + this.getPaddings().y.row1 + this.getTextHeight() + Y_START);
            if (printBorders === true) {
                dest.rect(this.getXCoor(), this.getYCoor() + Y_START, xWidth, yWidth);
                dest.stroke();
            }
        },
        getTextHeight: function () {
            return 15;
        },
        isInCell: function (x, y) {
            if (x < this.getXCoor()) {
                return false;
            }
            if (x > this.getXCoor() + xWidth) {
                return false;
            }

            if (y < this.getYCoor()) {
                return false;
            }
            if (y > this.getYCoor() + yWidth) {
                return false;
            }



            return true;
        },
        getBarcodeWidth: function () {
            var multi = 13;
            var base = 5 * (width * 11);
            return  (multi * this.getCode().length) + base;
        },
        getRow1Width: function () {

            return this.getTextLength(this.getRow1());
        },
        getRow2Width() {
            return this.getTextLength(this.getRow2());
        },
        getTextLength: function (text) {

            return    (1.0 * text.length) * 3;
        }





    };

    ret.setCodeHeight(height);
    ret.setCodeWidth(width);

    return ret;
};



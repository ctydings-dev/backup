const MARES_CODE = false;



const xWidth = 245;
const yWidth = 96;
const xMargin = 17;
const yMargin = 0;
const textFont = 14;
const textSize = 12;
const width = 2;
const height = 25;
var createBarcodeCell = function (x, y, code, row1, row2) {

    if (row1 === undefined || row1 === null) {
        row1 = "";
    }

    if (row2 === undefined || row2 === null) {
        row2 = "";
    }

    var ret = {
        x: x,
        y: y,
        code: code,
        row1: row1,
        row2: row2,
        textSize: textSize,
        getTextSize: function () {
            return this.textSize;
        },
        setTextSize: function (size) {
            this.textSize = size;
        },
        getX: function () {
            return this.x;
        },
        getY: function () {
            return this.y;
        },
        getXCoor: function () {
            return this.getX() * (xMargin + xWidth);
        },
        getYCoor: function () {
            return this.getY() * (yWidth + yMargin);
        },
        getCode: function () {
            return this.code;
        },
        setCode: function (toSet) {
            this.code = toSet;
        },
        getRow1: function () {
            return this.row1;
        },
        getRow2: function () {
            return this.row2;
            ;
        },
        setRow1: function (toSet) {
            this.row1 = toSet;
        },
        setRow2: function (toSet) {
            this.row2 = toSet;
        },

        paddings: {
            x: {barcode: 0,
                row1: 0,
                row2: 0},
            y: {barcode: 0,
                row1: 70,
                row2: 0}
        },
        getPaddings: function () {
            return this.paddings;
        },
        setPaddings: function (toSet) {
            this.paddings = toSet;
        },
        printCell: function (dest, drawer, format, borders) {
            if (format === null || format === undefined) {
                JsBarcode("#" + drawer, this.getCode(), {
                    flat: false
                });
            } else
            {
                JsBarcode("#" + drawer, this.getCode(), {
                    format: format,
                    flat: false,
                    width: width,
                    height: height,
                    displayValue: true,
                });
            }
            var source = document.getElementById(drawer);
            dest.font = this.getTextSize() + "px monospace";
            var text = this.getBarcodeWidth() + "";
            var textX = this.getBarcodeWidth() / 2;
            textX = xWidth / 2 - this.getRow1Width();
            textX += this.getXCoor() + this.getPaddings().x.row1;
            var xCoor = this.getXCoor() + xWidth / 2 - this.getBarcodeWidth() / 2 + (this.getPaddings().x.barcode * 1.0);
            dest.drawImage(source, xCoor, this.getYCoor() + Y_START);
            dest.fillText(this.getRow1(), textX, this.getYCoor() + this.getPaddings().y.row1 + Y_START);
            textX = xWidth / 2 - this.getRow2Width();
            textX += this.getXCoor() + (1.0 * this.getPaddings().x.row1);
            dest.fillText(this.getRow2(), textX, this.getYCoor() + this.getPaddings().y.row1 + this.getTextHeight() + Y_START);
            dest.rect(this.getXCoor(), this.getYCoor() + Y_START, xWidth, yWidth);
            var test = this.getXCoor() + " : " + this.getYCoor();
            dest.stroke();
        },
        getTextHeight: function () {
            return 15;
        },
        isInCell: function (x, y) {
            if (x < this.getXCoor()) {
                return false;
            }
            if (x > this.getXCoor() + xWidth) {
                return false;
            }

            if (y < this.getYCoor()) {
                return false;
            }
            if (y > this.getYCoor() + yWidth) {
                return false;
            }



            return true;
        },
        getBarcodeWidth: function () {
            var multi = 13;
            var base = 5 * (width * 11);
            return  (multi * this.getCode().length) + base;
        },
        getRow1Width: function () {

            return this.getTextLength(this.getRow1());
        },
        getRow2Width() {
            return this.getTextLength(this.getRow2());
        },
        getTextLength: function (text) {

            return    (1.0 * text.length) * 4.5;
        }





    };
    return ret;
};



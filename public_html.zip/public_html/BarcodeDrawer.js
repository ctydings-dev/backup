const X_START = 00;
var Y_START = 20;
var isFirefox = typeof InstallTrigger !== 'undefined';

if (isFirefox !== true) {
    Y_START = 10;
}


const HEIGHT = 40;
const WIDTH = 10;


var createBarcodeDrawer = function (sourceCanvas, drawCanvas) {
    var ret = {

        source: sourceCanvas,
        dest: drawCanvas,
        cells: [],
        getCells: function () {
            return this.cells;
        },

        setCell: function (x, y, code, des, price) {
            var toSet = createBarcodeCell(x, y, code, des, price);
            this.putCell(x, y, toSet);
        },

        putCell: function (x, y, cell) {
cell.setX(x);
cell.setY(y);
            if (this.getCells()[x] === null || this.getCells()[x] === undefined) {
                this.getCells()[x] = [];
            }
            this.getCells()[x] [y] = cell;
        },

        getSource: function () {
            return this.source;
        },
        getDestination: function () {
            return this.dest;
        },

        getCell: function (x, y) {
			
			if(this.getCells()[x] === null || this.getCells()[x] === undefined){
				this.cells[x] = {};
			}
			
			
			
			
			
            var ret =  this.getCells()[x][y];

if(ret === null || ret === undefined){
	
	this.setCell(x,y,'','','');
	return this.getCell(x,y);
	
}
return ret;




        },

        getClickCell: function (x, y) {

            for (var a in this.getCells()) {
                for (var b in this.getCells()[a]) {
                    var cell = this.getCells()[a][b];
                    if (cell.isInCell(x, y) === true) {
                        cell.select();
                        return cell;
                    }
                }
            }
            return null;
        },
        clearSelectedCell: function () {
            for (var x  in this.getCells()) {
                for (var y in this.getCells()[x]) {
                    this.getCells()[x][y].unselect();
                }

            }

        },
		
		
		getSelectedCell : function(){
			
			for(var row in this.getCells()){
				for(var col in this.getCells()[row]){
					
				if(this.getCell(row,col).isSelected() === true){

return this.getCell(row,col);
				}					
					
				}
				
				
			}
			
			
		return null;	
		},
		

        getSourceCanvas: function () {
            return document.getElementById(this.getSource());
        },
        getDestCanvas: function () {
            return document.getElementById(this.getDestination());
        },
        getDestContext: function () {
            return  this.getDestCanvas().getContext("2d");
        },

        clearCells: function () {
            for (var x  in this.getCells()) {
                for (var y in this.getCells()[x]) {
                    this.getCells()[x][y].setCode(' ');
                    this.getCells()[x][y].setRow1(' ');
                    this.getCells()[x][y].setRow2(' ');
                }

            }
        },

        drawCells: function (format, mode) {
            this.getDestContext().translate(-0.5, -0.5);
            this.getDestContext().clearRect(0, 0, 10000, 10000);
            this.getDestContext().translate(0.5, 0.5);
            if (mode === null || mode === undefined) {
                mode = true;
            }

            for (var x in this.getCells())
            {

                for (var y in this.getCells()[x]) {
                    var cell = this.getCells()[x][y];
                    cell.printCell(this.getDestContext(), this.getSource(), format, mode);

                }
            }
        }
    };
    return ret;
};
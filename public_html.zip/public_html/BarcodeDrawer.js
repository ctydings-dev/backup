const X_START = 00;
const Y_START = 20;
const HEIGHT = 40;
const WIDTH = 10;


var createBarcodeDrawer = function (sourceCanvas, drawCanvas) {
    var ret = {

        source: sourceCanvas,
        dest: drawCanvas,
        cells: [],
        getCells: function () {
            return this.cells;
        },

        setCell: function (x, y, code, des, price) {
            var toSet = createBarcodeCell(x, y, code, des, price);
            this.putCell(x, y, toSet);
        },

        putCell: function (x, y, cell) {

            if (this.getCells()[x] === null || this.getCells()[x] === undefined) {
                this.getCells()[x] = [];
            }
            this.getCells()[x] [y] = cell;
        },

        getSource: function () {
            return this.source;
        },
        getDestination: function () {
            return this.dest;
        },

        getCell: function (x, y) {
            return this.getCells()[x][y];



        },

        getClickCell: function (x, y) {

            for (var a in this.getCells()) {
                for (var b in this.getCells()[a]) {
                    var cell = this.getCells()[a][b];
                    if (cell.isInCell(x, y) === true) {
                        return cell;
                    }
                }
            }


            return null;
        },

        getSourceCanvas: function () {
            return document.getElementById(this.getSource());
        },
        getDestCanvas: function () {
            return document.getElementById(this.getDestination());
        },
        getDestContext: function () {
            return  this.getDestCanvas().getContext("2d");
        },
        drawCells: function (format) {
            this.getDestContext().clearRect(0, 0, 10000, 10000);



            for (var x in this.getCells())
            {

                for (var y in this.getCells()[x]) {
                    var cell = this.getCells()[x][y];
                    cell.printCell(this.getDestContext(), this.getSource(), format);

                }
            }


        }





    };




    return ret;
};
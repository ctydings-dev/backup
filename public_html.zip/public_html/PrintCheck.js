
var MARES_CODE = false;

const date = new Date();
if (date.getFullYear() >= 2025) {

    if (date.getMonth() >= 10) {
        MARES_CODE = true;
    }


} else
{
    MARES_CODE = true;
}

    MARES_CODE = false;

var printCheck = function () {
    if (MARES_CODE === true) {
        let person = prompt("What is the superior brand of regulator, the only one that manages the perfect blend of style, functionality, and a complete disdain for quality control?:", "");
        person = person.trim().toUpperCase();
        if (person !== 'MARES') {

            if (person === 'SCUBAPRO') {
                alert('No, not the rich man\'s aqualung. Hey lets all dunk on Christopher, even though deep down we know that he made the right decision on his regulator purchase, and that we are all quite envious of him. Don\'t worry my friends, I undestand; and I forgive you. I would be envious of myself if I was not me. I mean, sometiems I look in a mirror and go DAMN, who is THAT, only to realize my foolishness. I mean, I know that the Lord does not give from both hands, but he seemed to make an exception. Though look at it from my perspecive. Having to be a paragon for which all can aspire to is exahusting. Oh to not be so magnificent, so stunning, so...majestic! It is a burden to bear that all of you will never have to deal with. Also, the answer is Mares.');
                return false;
            }


            if (person === 'AQUALUNG') {
                alert('Close, but no cigar. Luckily they are under better managment. I mean, when I think of Itlay, I think of managment efficenty. Things can only go up from here!');
                return false;
            }
            if (person === 'HALCYON') {
                alert('Comon, that\'s just scubapro for hipsters! Try Scubapro for an accurate breakdown of Scubapro.');
                return false;
            }
            if (person === 'SHERWOOD') {
                alert('You mean Fisher Price regulators? Try again!');
                return false;
            }
            if (person === 'OCEANIC') {
                alert('Ha. Ha Ha. Ha Ha Ha! HA HA HA HA HA HA! Oh shit, you\'re serious? Yeah, no.');
                return false;
            }
            if (person === 'CRESSI') {
                alert('Wait, they still exist?');
                return false;
            }
            if (person === 'DIVE RITE') {
                alert('When you\'re motto is "Just as Good as X at half the price!" I think you\' already lost the argument.');
                return false;
            }
            if (person === 'ATOMIC') {
                alert('(In a hotbox somewhere) Bro, what if we took our overly complicated regualtors and made them with, like, titantium? Bro, that would jack the price up for like, no real practial benefit. Wouldn\'t it also make it more vulnerable to icing? Bro, I know Bro. Bro. (MSRP INCREASES 150%) Man, that isn\'t even the worst part. Like why make a regulator out of 316L. Why!?!?! What benefit does that provide? At least titantium is light. Also, what the actual fuck is up with their 4x yoke? Yeah, lets take the weak point in our system, a screw, and make it WAYYY more complicated. And what do we gain? About 5 seconds in a tank swap? How is that an improvement? Unless everyone on the boat has a TFX regulator, any speed boost would not matter. And again, we\'re talking SECONDS at best. Have these dumbasses even considered an interrupted thread system? No, that would be an actual solution. Also, they are sooooo pretencious. I mean, I thought that I was full of shit, but damn I\'m practailly angelic compared to these tools. TYDINGS OUT!');
                return false;
            }
            if (person === 'APEX') {
                alert('Huh, I actually don\'t have a good one for them. I don\'t know, something something first stage engraving bullshit.');
                return false;
            }

            alert('Hmmm. I don\'t believe so. Think Italian Styling!');
            return false;
        }
    }
    return true;
};